### RUN

> python main_vi.py

OR 

### build docker-compose

> docker-compose up --build -d

### need for install pyaudio
> sudo apt-get install portaudio19-dev

### convert sang file .wav 16k 1chanel nếu chưa đúng chuẩn
> ffmpeg -i 111.mp3 -acodec pcm_s16le -ac 1 -ar 16000 out.wav

